﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterCode
{
    class Program
    {
       static MasterMind MasterMindApp = new MasterMind();
        static void Main(string[] args)
        {
            MasterMindApp.startAttempts();
        }
    }
}
