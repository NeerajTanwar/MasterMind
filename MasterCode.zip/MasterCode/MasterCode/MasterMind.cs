﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Collections;
namespace MasterCode
{

    class MasterMind
    {

        private int MIN_RANGE = 1;

        private int MAX_RANGE = 6;

        private int NUM_OF_DIGITS = 4;

        private int NUM_OF_ATTEMPTS = 10;

        private Char[] randomNumArray;

        private Dictionary<Int32, Int32> digitsToFreqMap = new Dictionary<Int32, int>();
        Hashtable MyHash = new Hashtable();
        public MasterMind()
        {
            generateRandomNumber(MIN_RANGE, MAX_RANGE, NUM_OF_DIGITS);
            // populateCharToFreqMap();
            PopulateHashTable();
        }

        private void generateRandomNumber(int min_range, int max_range, int num_of_digits)
        {
            this.randomNumArray = new char[num_of_digits];
            this.digitsToFreqMap = new Dictionary<Int32, Int32>();
            for (int count = 0; (count < num_of_digits); count++)
            {
                Random Rand = new Random();

                this.randomNumArray[count] = Convert.ToChar(Rand.Next(min_range, max_range));
            }

        }
        public void startAttempts()
        {
            for (int count = 0; (count < this.NUM_OF_ATTEMPTS); count++)
            {
                if (this.attempt(count))
                {
                    Console.WriteLine("YOU WIN");
                    return;
                }

            }

            Console.WriteLine("YOU LOSE");
        }
        private bool validate(String inputNumber)
        {

            Regex regex = new Regex(@"[\d]");

            if ((inputNumber == null) || (inputNumber == "") || !regex.IsMatch(inputNumber))


            {
                return false;
            }

            return true;
        }
        private void clearCharToFreqMap()
        {
            this.digitsToFreqMap.Clear();
        }
        private bool attempt(int count)
        {
            Console.WriteLine("Enter your Number" + Environment.NewLine);
            String inputNumber = Console.ReadLine();
            while (!this.validate(inputNumber))
            {
                Console.WriteLine("Enter a valid combination: ");
                inputNumber = Console.ReadLine();
            }
            
           
            StringBuilder playerOutput = new StringBuilder("");
         
            
            for (int index = 0; index < inputNumber.Length; index++)
            {
                


                Int32 Frequency = 0;
                char key = inputNumber[index];
                ///sir can you please check this line why its not going into if block
                if (MyHash.ContainsKey(key))
                {
                    //Frequency = digitsToFreqMap[inputNumber[index]];
                    Frequency = Convert.ToInt32(MyHash[inputNumber[index]]);
                }



                if (Frequency > 0)
                {
                    this.digitsToFreqMap.Add(inputNumber[index], (Frequency - 1));

                    if (((index < this.NUM_OF_DIGITS)
                           && (inputNumber[index] == this.randomNumArray[index])))
                    {
                        playerOutput.Append("+");
                    }
                    else
                    {
                        playerOutput.Append("-");
                    }
                }

                }
            this.clearCharToFreqMap();
            if (((playerOutput.ToString().Length == this.NUM_OF_DIGITS)
                   && ((inputNumber.Length == this.NUM_OF_DIGITS)
                   && (playerOutput.ToString().IndexOf("-") == -1))))
            {
                return true;
            }
            Console.WriteLine(("Hint: " + playerOutput.ToString()));
            return false;
        }
        private void populateCharToFreqMap()
        {
            for (int count = 0; (count < this.randomNumArray.Length); count++)
            {
            
                if(digitsToFreqMap.ContainsKey(this.randomNumArray[count]))
                {
                    digitsToFreqMap[this.randomNumArray[count]]++;
                    
                }
                else
                {
                    digitsToFreqMap[this.randomNumArray[count]] = 1;
                }
               
            }

            

        }
        private void PopulateHashTable()
        {
            Int32 Value = 0;
            for (int count = 0; (count < this.randomNumArray.Length); count++)
            {

                if(MyHash.ContainsKey(randomNumArray[count]))
                {
                    //digitsToFreqMap[this.randomNumArray[count]]++;
                    Value = Convert.ToInt32(MyHash[randomNumArray[count]]);
                    Value++;
                    MyHash[randomNumArray[count]] = Value;
                }
                else
                {
                    // digitsToFreqMap[this.randomNumArray[count]] = 1;
                    Value = 1;
                    MyHash.Add(randomNumArray[count], Value);
                }

            }
        }

    }
}
